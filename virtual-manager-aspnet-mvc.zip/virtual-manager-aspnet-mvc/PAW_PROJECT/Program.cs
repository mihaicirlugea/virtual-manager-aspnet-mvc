﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.EntityFrameworkCore;
using PAW_PROJECT.Data;
using PAW_PROJECT.Models;
using PAW_PROJECT.Repositories;
using PAW_PROJECT.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. Înregistrare Repository și Service existente
builder.Services.AddScoped<IEcosistemRepository, EcosistemRepository>();
builder.Services.AddScoped<IEcosistemService, EcosistemService>();

builder.Services.AddScoped<IFluxCapitalRepository, FluxCapitalRepository>();
builder.Services.AddScoped<IFluxCapitalService, FluxCapitalService>();

builder.Services.AddScoped<IActivitateRepository, ActivitateRepository>();
builder.Services.AddScoped<IActivitateService, ActivitateService>();

// 2. Adaugă serviciul pentru Baza de Date
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite("Data Source=Ecosisteme.db"));

// 3. Configurare ASP.NET Core Identity cu ApplicationUser
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = false;
    options.Password.RequiredLength = 6;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

// 4. Înregistrarea serviciului custom de autentificare
builder.Services.AddScoped<IAuthService, AuthService>();

// Adaugă serviciile pentru Controller + Views
builder.Services.AddControllersWithViews(options =>
{
    var policy = new AuthorizationPolicyBuilder()
                     .RequireAuthenticatedUser()
                     .Build();
    options.Filters.Add(new AuthorizeFilter(policy));
})
    
    ; var app = builder.Build();

// Configurează pipeline-ul HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Autentificarea înainte de Autorizare
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Executăm crearea automată a rolurilor și a contului de Admin
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        await IdentitySeed.SeedRolesAndAdminAsync(services);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Eroare la Seed: {ex.Message}");
    }
}

app.Run();